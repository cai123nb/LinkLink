package link.cjyong.com.linklink.util;

import android.app.Application;

/**
 * Created by cjyong on 2017/3/27.
 * 项目的实例类,用于存储一些全局变量和方便工具类获取上下文
 */

public class MyApplication extends Application
{
    //为需要的工具类提供Application的实例,方便调用上下文资源
    private static MyApplication instance;

    public static MyApplication getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        // TODO Auto-generated method stub
        super.onCreate();
        instance = this;
    }
}
