package link.cjyong.com.linklink.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;

import link.cjyong.com.linklink.util.ImageUtil;

/**
 * Created by cjyong on 2017/3/29.
 */

public class Barrier extends View
{
    private Bitmap bitmap;  //关卡图标
    private boolean locked; //是否解锁
    private Bitmap lockBitmap; //锁的图标

    public Barrier(Context context, AttributeSet sttrs)
    {
        super(context,sttrs);
        this.bitmap = ImageUtil.getBarrierImage(context);
        this.lockBitmap = ImageUtil.getLockImage(context);
        this.locked = false;
    }


    public Bitmap getLockBitmap() {
        return lockBitmap;
    }

    public void setLockBitmap(Bitmap lockBitmap) {
        this.lockBitmap = lockBitmap;
    }

    public Bitmap getBitmap() {
        return bitmap;
    }

    public void setBitmap(Bitmap bitmap) {
        this.bitmap = bitmap;
    }

    public boolean isLocked() {
        return locked;
    }

    public void setLocked(boolean locked) {
        this.locked = locked;
    }



    @Override
    protected void onDraw(Canvas canvas)
    {
        //绘制图标
        canvas.drawBitmap(bitmap,0,0,null);
        if(this.locked)
        {
            //加锁
            canvas.drawBitmap(lockBitmap,10,10,null);
        }
    }
}
