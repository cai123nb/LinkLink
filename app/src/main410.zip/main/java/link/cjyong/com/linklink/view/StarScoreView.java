package link.cjyong.com.linklink.view;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.util.AttributeSet;
import android.view.View;

import link.cjyong.com.linklink.R;
import link.cjyong.com.linklink.util.ImageUtil;

/**
 * Created by cjyong on 2017/3/27.
 */

public class StarScoreView extends View
{
    private int howManyStars=1;

    private Bitmap starbm,blackStarbm;

    public StarScoreView(Context context,AttributeSet attrs)
    {
        super(context,attrs);
        //对星星图标赋处值
        this.starbm = ImageUtil.getStarImage(context);
        this.blackStarbm = ImageUtil.getBlackStarImage(context);
    }


    @Override
    protected void onDraw(Canvas canvas)
    {
        super.onDraw(canvas);
        if(howManyStars==1)//一颗星过关
        {
            canvas.drawBitmap(starbm,0,0,null);
            canvas.drawBitmap(blackStarbm,70,50,null);
            canvas.drawBitmap(blackStarbm,140,10,null);

        }
        else if(howManyStars == 2)
        {
            canvas.drawBitmap(starbm,10,10,null);
            canvas.drawBitmap(starbm,50,50,null);
            canvas.drawBitmap(blackStarbm,100,10,null);
        }
        else
        {
            canvas.drawBitmap(starbm,10,10,null);
            canvas.drawBitmap(starbm,50,50,null);
            canvas.drawBitmap(starbm,100,10,null);
        }
    }


    public void setHowManyStars(int howManyStars) {
        this.howManyStars = howManyStars;
    }
    public int getHowManyStars() {
        return howManyStars;
    }

}
