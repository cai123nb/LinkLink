package link.cjyong.com.linklink.service;

import android.util.Log;
import android.widget.Toast;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import link.cjyong.com.linklink.Activity.registerActivity.registerActivity;

/**
 * Created by cjyong on 2017/4/7.
 */

public class SendMailThread extends Thread {
    private String recipientAddress;
    private String username;
    private String activatedCode;
    public SendMailThread(String username,String recipientAddress,String activatedCode){
        this.username=username;
        this.recipientAddress=recipientAddress;
        this.activatedCode=activatedCode;
    }

    public void run(){
        Mail m = new Mail("18375637632@163.com", "cai123nb");
        String[] toArr = {recipientAddress};
        m.set_to(toArr);
        m.set_from("18375637632@163.com");
        m.set_subject("LinkLink游戏注册成功");
        m.setBody("恭喜您: "+username+" 注册LinkLink游戏成功,你的激活码是: "+activatedCode+" \n请及时查收");
        try {
            //m.addAttachment("/sdcard/filelocation");
            m.send();

        } catch (Exception e) {
            // Toast.makeText(MailApp.this,
            // "There was a problem sending the email.",
            // Toast.LENGTH_LONG).show();
            Log.e("MailApp", "Could not send email", e);
        }
    }
}
