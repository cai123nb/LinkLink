package link.cjyong.com.linklink.Activity.MainActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import link.cjyong.com.linklink.R;
import link.cjyong.com.linklink.Activity.firstHurdleActivity.FirstHurdleActivity;
import link.cjyong.com.linklink.Activity.secondHurdleActivity.SecondHurdleActivity;

public class MainActivity extends AppCompatActivity
{
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    private LinearLayout ll;
    private Button btnBag,btnShop,btnAddDiamond,btnAddGold,btnExit,btnSetting,btnAuthor;
    private TextView tvDiamond,tvGold;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //设置横屏
        getSupportActionBar().hide();
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.activity_main);
        //游戏初始化操作
        init();
        //添加关卡
        addHurdles();
    }

    //初始化操作,绑定各类组件和监听器
    private void init()
    {
        //绑定组件
        btnBag = (Button) findViewById(R.id.bagBtn);
        btnShop = (Button) findViewById(R.id.shopBtn);
        btnAddDiamond = (Button) findViewById(R.id.addDiamond);
        btnAddGold = (Button) findViewById(R.id.addGold);
        btnExit = (Button) findViewById(R.id.exitBtn);
        btnSetting = (Button) findViewById(R.id.settingBtn);
        btnAuthor = (Button) findViewById(R.id.authorBtn);
        tvDiamond = (TextView) findViewById(R.id.diamondTv);
        tvGold = (TextView) findViewById(R.id.goldTv);
        ll = (LinearLayout) findViewById(R.id.hsvll);

        //获取用户通关数据
        preferences = getSharedPreferences("gameData",0);
        editor = preferences.edit();
        int first = preferences.getInt("1.1",-1);
        int gold = preferences.getInt("gold",0);
        int diamond = preferences.getInt("diamond",0);
        if(first==-1)
        {
            //第一次玩
            editor.putInt("11",0);
            editor.commit();
        }
        tvGold.setText(tvGold.getText()+" "+gold);
        tvDiamond.setText(tvDiamond.getText()+" "+diamond);
        //设置背包监听器
        btnBag.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里添加启动背包的活动
            }
        });

        //设置商店监听器
        btnShop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里添加启动商店的活动
            }
        });

        //设置添加钻石监听器
        btnAddDiamond.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里添加启动添加钻石的活动
            }
        });

        //设置添加金币监听器
        btnAddGold.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里添加启动添加金币的活动
            }
        });

        //设置退出监听器
        btnExit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里添加启动动退出的活动
                exitConfirm();
            }
        });

        //设置设置按钮监听器
        btnSetting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里添加启动设置的活动
            }
        });

        //设置鸣谢监听器
        btnAuthor.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里添加启动鸣谢的活动
            }
        });
    }

    //添加不同的关卡主题
    void addHurdles()
    {
        for(int i=0;i<10;i++)
        {
            if(i==0)
            {
                //第一个大关卡
                Button btn1 = new Button(this);
                btn1.setText("第"+(i+1)+"章节");
                btn1.setHeight(800);
                btn1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //启动第一关关卡
                        Intent intent = new Intent(MainActivity.this
                                , FirstHurdleActivity.class);
                        startActivity(intent);
                        // 结束该Activity
                        finish();
                    }
                });
                ll.addView(btn1);
            }
            else if(i==1)
            {
                //添加第二个大关卡
                Button btn1 = new Button(this);
                btn1.setText("第"+(i+1)+"章节");
                btn1.setHeight(800);
                btn1.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        //启动第一关关卡
                        Intent intent = new Intent(MainActivity.this
                                , SecondHurdleActivity.class);
                        startActivity(intent);
                        // 结束该Activity
                        finish();
                    }
                });
                ll.addView(btn1);
            }
            else
            {
                Button btn = new Button(this);
                btn.setText("第"+(i+1)+"章节");
                btn.setHeight(800);
                ll.addView(btn);
            }

        }
    }


    //退出进行弹框确认
    private void exitConfirm()
    {
        AlertDialog alertDialog = new AlertDialog.Builder(MainActivity.this)
                .setTitle("退出程序")
                .setMessage("您确认要退出吗?")
                .setPositiveButton("确定", new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which)
                        {System.exit(0); }
                    })
                .setNegativeButton("取消", new DialogInterface.OnClickListener() {
                        public void onClick(DialogInterface dialog, int which)
                        { return;}
                }).create();
        alertDialog.show();
    }
}
