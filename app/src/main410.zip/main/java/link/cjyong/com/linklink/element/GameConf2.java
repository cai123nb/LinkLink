package link.cjyong.com.linklink.element;

import android.os.Parcel;
import android.os.Parcelable;

/**
 * Created by cjyong on 2017/4/3.
 */

public class GameConf2 implements Parcelable
{
    // 设置连连看的每个方块的图片的宽、高
    public static final int PIECE_WIDTH = 120;
    public static final int PIECE_HEIGHT = 120;
    //记录关卡的标志
    private String barrierID;
    // Piece[][]数组第一维的长度
    private int xSize;
    // Piece[][]数组第二维的长度
    private int ySize;
    // Board中第一张图片出现的x座标
    private int beginImageX;
    // Board中第一张图片出现的y座标
    private int beginImageY;
    // 记录游戏的总步数
    private int gameStep;
    // 记录关卡的评分标准
    private String taskRequirements;
    // 记录关卡的类型
    private int taskKind;

    public GameConf2(){};
    public GameConf2(String barrierID,int xSize, int ySize, int beginImageX,
                    int beginImageY, int gameStep, String taskRequirements,int taskKind)
    {
        this.barrierID = barrierID;
        this.xSize = xSize;
        this.ySize = ySize;
        this.beginImageX = beginImageX;
        this.beginImageY = beginImageY;
        this.gameStep = gameStep;
        this.taskRequirements =  taskRequirements;
        this.taskKind = taskKind;
    }

    public String getBarrierID() {
        return barrierID;
    }
    public void setBarrierID(String barrierID) {
        this.barrierID = barrierID;
    }
    public int getxSize() {
        return xSize;
    }

    public void setxSize(int xSize) {
        this.xSize = xSize;
    }

    public int getySize() {
        return ySize;
    }

    public void setySize(int ySize) {
        this.ySize = ySize;
    }

    public int getBeginImageX() {
        return beginImageX;
    }

    public void setBeginImageX(int beginImageX) {
        this.beginImageX = beginImageX;
    }

    public int getBeginImageY() {
        return beginImageY;
    }

    public void setBeginImageY(int beginImageY) {
        this.beginImageY = beginImageY;
    }

    public int getGameStep() {
        return gameStep;
    }

    public void setGameStep(int gameStep) {
        this.gameStep = gameStep;
    }

    public String getTaskRequirements() {
        return taskRequirements;
    }

    public void setTaskRequirements(String taskRequirements) {
        this.taskRequirements = taskRequirements;
    }

    public int getTaskKind()
    {
        return taskKind;
    }

    public void setTaskKind(int taskKind)
    {
        this.taskKind = taskKind;
    }


    @Override
    public int describeContents() {
        return 0;
    }
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(barrierID);
        dest.writeInt(xSize);
        dest.writeInt(ySize);
        dest.writeInt(beginImageX);
        dest.writeInt(beginImageY);
        dest.writeInt(gameStep);
        dest.writeString(taskRequirements);
        dest.writeInt(taskKind);
    }
    public static final Parcelable.Creator<GameConf2> CREATOR = new Parcelable.Creator<GameConf2>() {
        @Override
        public GameConf2 createFromParcel(Parcel source) {
            GameConf2 gameConf2 = new GameConf2();
            gameConf2.barrierID = source.readString();
            gameConf2.xSize = source.readInt();
            gameConf2.ySize = source.readInt();
            gameConf2.beginImageX = source.readInt();
            gameConf2.beginImageY = source.readInt();
            gameConf2.gameStep = source.readInt();
            gameConf2.taskRequirements = source.readString();
            gameConf2.taskKind = source.readInt();
            return gameConf2;
        }
        @Override
        public GameConf2[] newArray(int size) {
            return new GameConf2[size];
        }
    };
}
