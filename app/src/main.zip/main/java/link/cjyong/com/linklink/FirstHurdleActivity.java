package link.cjyong.com.linklink;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.RatingBar;

import link.cjyong.com.linklink.element.GameConf;
import link.cjyong.com.linklink.element.HomeListener;
import link.cjyong.com.linklink.view.Barrier;

/**
 * Created by cjyong on 2017/3/22.
 */

public class FirstHurdleActivity extends Activity
{
    private Barrier firstBarrier,secondBarrier,thirdBarrier,fourthBarrier,fifthBarrier,sixthBarrier;
    private RatingBar firstRb,secondRb,thirdRb,fourthRb,fifthRb,sixthRb;
    private Button returnbtn;
    private GameConf gameConf;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.first_hurdle);
        //设置横屏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        //初始化游戏
        init();
    }
    //游戏初始操作
    protected void init()
    {
        //绑定组件
        firstBarrier = (Barrier) findViewById(R.id.first_hurdle);
        secondBarrier = (Barrier) findViewById(R.id.second_hurdle);
        thirdBarrier = (Barrier) findViewById(R.id.thirld_hurdle);
        fourthBarrier = (Barrier) findViewById(R.id.fourth_hurlde);
        fifthBarrier = (Barrier) findViewById(R.id.fifth_hurdle);
        sixthBarrier = (Barrier) findViewById(R.id.sixth_hurdle);
        returnbtn = (Button) findViewById(R.id.return_home);
        firstRb = (RatingBar) findViewById(R.id.first_rb);
        secondRb = (RatingBar) findViewById(R.id.second_rd);
        thirdRb = (RatingBar) findViewById(R.id.thirld_rd);
        fourthRb = (RatingBar) findViewById(R.id.fourth_rd);
        fifthRb = (RatingBar) findViewById(R.id.fifth_rd);
        sixthRb = (RatingBar) findViewById(R.id.fifth_rd);

        //获取用户通关数据
        preferences = getSharedPreferences("gameData",0);
        editor = preferences.edit();
        int first = preferences.getInt("11",-1);
        int second = preferences.getInt("12",-1);
        int third = preferences.getInt("13",-1);
        int fourth = preferences.getInt("14",-1);
        int fifth  = preferences.getInt("15",-1);
        int sixth = preferences.getInt("16",-1);
        if(first>-1)
        {
            firstRb.setVisibility(View.VISIBLE);
            firstRb.setRating(first);
        }

        if(second>-1)
        {
            secondRb.setVisibility(View.VISIBLE);
            secondRb.setRating(second);
            secondBarrier.setEnabled(true);
        }
        else
        {
            secondBarrier.setLocked(true);
            secondBarrier.setEnabled(false);
            secondBarrier.postInvalidate();
        }

        if(third>-1)
        {
            thirdRb.setVisibility(View.VISIBLE);
            thirdRb.setRating(third);
        }
        else
        {
            thirdBarrier.setLocked(true);
            thirdBarrier.setEnabled(false);
            thirdBarrier.postInvalidate();
        }
        if(fourth>-1)
        {
            fourthRb.setVisibility(View.VISIBLE);
            fourthRb.setRating(fourth);
            thirdBarrier.setEnabled(true);
        }
        else
        {
            fourthBarrier.setLocked(true);
            fourthBarrier.setEnabled(false);
            fourthBarrier.postInvalidate();
        }

        if(fifth>-1)
        {
            fifthRb.setVisibility(View.VISIBLE);
            fifthRb.setRating(fifth);
            fifthBarrier.setEnabled(true);
        }
        else
        {
            fifthBarrier.setLocked(true);
            fifthBarrier.setEnabled(false);
            fifthBarrier.postInvalidate();
        }

        if(sixth>-1)
        {
            sixthRb.setVisibility(View.VISIBLE);
            sixthRb.setRating(sixth);
            sixthBarrier.setEnabled(true);
        }
        else
        {
            sixthBarrier.setLocked(true);
            sixthBarrier.setEnabled(false);
            sixthBarrier.postInvalidate();
        }

        //绑定监听器
        firstBarrier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里添加第一关
                Intent intent = new Intent(FirstHurdleActivity.this,GameActivity.class);
                //传入对应的参数
                gameConf = new GameConf("11",5, 5, 2, 10,20,"1星:20秒\n2星15秒\n3星8秒",0);
                Bundle bundle = new Bundle();
                bundle.putParcelable("gameConf",gameConf);
                intent.putExtras(bundle);
                startActivity(intent);
                // 结束该Activity
                finish();
            }
        });
        secondBarrier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里添加第二关
                //这里添加第一关
                Intent intent = new Intent(FirstHurdleActivity.this,GameActivity.class);
                //传入对应的参数
                gameConf = new GameConf("12",5, 5, 2, 10, 20,"1星:20秒\n2星15秒\n3星10秒",0);
                Bundle bundle = new Bundle();
                bundle.putParcelable("gameConf",gameConf);
                intent.putExtras(bundle);
                startActivity(intent);
                // 结束该Activity
                finish();
            }
        });
        thirdBarrier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里添加第三关
                //这里添加第一关
                Intent intent = new Intent(FirstHurdleActivity.this,GameActivity.class);
                //传入对应的参数
                gameConf = new GameConf("13",7, 7, 2, 10, 20,"1星:20秒\n2星15秒\n3星10秒",1);
                Bundle bundle = new Bundle();
                bundle.putParcelable("gameConf",gameConf);
                intent.putExtras(bundle);
                startActivity(intent);
                // 结束该Activity
                finish();
            }
        });
        fourthBarrier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里添加第四关
                //这里添加第一关
                Intent intent = new Intent(FirstHurdleActivity.this,GameActivity.class);
                //传入对应的参数
                gameConf = new GameConf("14",7, 7, 2, 10, 20,"1星:20秒\n2星15秒\n3星10秒",2);
                Bundle bundle = new Bundle();
                bundle.putParcelable("gameConf",gameConf);
                intent.putExtras(bundle);
                startActivity(intent);
                // 结束该Activity
                finish();
            }
        });
        fifthBarrier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里添加第五关
                //这里添加第一关
                Intent intent = new Intent(FirstHurdleActivity.this,GameActivity.class);
                //传入对应的参数
                gameConf = new GameConf("15",9, 9, 2, 10, 40,"1星:40秒\n2星30秒\n3星25秒",0);
                Bundle bundle = new Bundle();
                bundle.putParcelable("gameConf",gameConf);
                intent.putExtras(bundle);
                startActivity(intent);
                // 结束该Activity
                finish();
            }
        });
        sixthBarrier.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里添加第六关
                //这里添加第一关
                Intent intent = new Intent(FirstHurdleActivity.this,GameActivity.class);
                //传入对应的参数
                gameConf = new GameConf("16",11, 11, 2, 10, 60,"1星:60秒\n2星50秒\n3星35秒",0);
                Bundle bundle = new Bundle();
                bundle.putParcelable("gameConf",gameConf);
                intent.putExtras(bundle);
                startActivity(intent);
                // 结束该Activity
                finish();
            }
        });
        returnbtn.setOnClickListener(new HomeListener(this));
    }


}
