package link.cjyong.com.linklink.view;

import android.graphics.Bitmap;

/**
 * Created by cjyong on 2017/3/22.
 */

public class PieceImage
{
    private Bitmap image;
    private int imageId;
    // 有参数的构造器
    public PieceImage(Bitmap image, int imageId)
    {
        super();
        this.image = image;
        this.imageId = imageId;
    }
    public Bitmap getImage()
    {
        return image;
    }
    public void setImage(Bitmap image)
    {
        this.image = image;
    }
    public int getImageId()
    {
        return imageId;
    }
    public void setImageId(int imageId)
    {
        this.imageId = imageId;
    }
}
