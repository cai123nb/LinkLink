package link.cjyong.com.linklink.element;

import android.os.Parcel;
import android.os.Parcelable;


/**
 * Created by cjyong on 2017/3/23.
 */

public class GameConf implements Parcelable
{
    // 设置连连看的每个方块的图片的宽、高
    public static final int PIECE_WIDTH = 120;
    public static final int PIECE_HEIGHT = 120;
    // 记录游戏的总时间（100秒）.
    public static int DEFAULT_TIME = 60;
    //记录关卡的标志
    private String barrierID;
    // Piece[][]数组第一维的长度
    private int xSize;
    // Piece[][]数组第二维的长度
    private int ySize;
    // Board中第一张图片出现的x座标
    private int beginImageX;
    // Board中第一张图片出现的y座标
    private int beginImageY;
    // 记录游戏的总时间, 单位是秒
    private int gameTime;
    // 记录关卡的评分标准
    private String taskRequirements;
    // 记录关卡的类型
    private int taskKind;

    public GameConf(){};
    public GameConf(String barrierID,int xSize, int ySize, int beginImageX,
                    int beginImageY, int gameTime, String taskRequirements,int taskKind)
    {
        this.barrierID = barrierID;
        this.xSize = xSize;
        this.ySize = ySize;
        this.beginImageX = beginImageX;
        this.beginImageY = beginImageY;
        this.gameTime = gameTime;
        this.taskRequirements =  taskRequirements;
        this.taskKind = taskKind;
    }

    public String getBarrierID() {
        return barrierID;
    }
    public void setBarrierID(String barrierID) {
        this.barrierID = barrierID;
    }
    public int getxSize() {
        return xSize;
    }

    public void setxSize(int xSize) {
        this.xSize = xSize;
    }

    public int getySize() {
        return ySize;
    }

    public void setySize(int ySize) {
        this.ySize = ySize;
    }

    public int getBeginImageX() {
        return beginImageX;
    }

    public void setBeginImageX(int beginImageX) {
        this.beginImageX = beginImageX;
    }

    public int getBeginImageY() {
        return beginImageY;
    }

    public void setBeginImageY(int beginImageY) {
        this.beginImageY = beginImageY;
    }

    public int getGameTime() {
        return gameTime;
    }

    public void setGameTime(int gameTime) {
        this.gameTime = gameTime;
    }

    public String getTaskRequirements() {
        return taskRequirements;
    }

    public void setTaskRequirements(String taskRequirements) {
        this.taskRequirements = taskRequirements;
    }

    public int getTaskKind()
    {
        return taskKind;
    }

    public void setTaskKind(int taskKind)
    {
        this.taskKind = taskKind;
    }


    @Override
    public int describeContents() {
        return 0;
    }
    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(barrierID);
        dest.writeInt(xSize);
        dest.writeInt(ySize);
        dest.writeInt(beginImageX);
        dest.writeInt(beginImageY);
        dest.writeInt(gameTime);
        dest.writeString(taskRequirements);
        dest.writeInt(taskKind);
    }
    public static final Parcelable.Creator<GameConf> CREATOR = new Creator<GameConf>() {
        @Override
        public GameConf createFromParcel(Parcel source) {
            GameConf gameConf = new GameConf();
            gameConf.barrierID = source.readString();
            gameConf.xSize = source.readInt();
            gameConf.ySize = source.readInt();
            gameConf.beginImageX = source.readInt();
            gameConf.beginImageY = source.readInt();
            gameConf.gameTime = source.readInt();
            gameConf.taskRequirements = source.readString();
            gameConf.taskKind = source.readInt();
            return gameConf;
        }
        @Override
        public GameConf[] newArray(int size) {
            return new GameConf[size];
        }
    };
}
