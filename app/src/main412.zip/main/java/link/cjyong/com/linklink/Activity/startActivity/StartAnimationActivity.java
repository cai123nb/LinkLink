package link.cjyong.com.linklink.Activity.startActivity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.graphics.drawable.AnimationDrawable;
import android.os.Bundle;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.ImageView;

import link.cjyong.com.linklink.Activity.MainActivity.MainActivity;
import link.cjyong.com.linklink.Activity.registerActivity.registerActivity;
import link.cjyong.com.linklink.R;

/**
 * Created by cjyong on 2017/4/7.
 */

public class StartAnimationActivity extends Activity
{
    private ImageView iv;
    protected AnimationDrawable ad;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //设置横屏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.start_main);
        //获取动画
        iv = (ImageView) findViewById(R.id.image);
        ad = (AnimationDrawable) iv.getBackground();
        Animation am = AnimationUtils.loadAnimation(this, R.anim.alphaanimation);
        iv.setAnimation(am);
        am.setAnimationListener(new Animation.AnimationListener() {
            @Override
            public void onAnimationStart(Animation animation) {
                ad.start();
            }

            @Override
            public void onAnimationEnd(Animation animation) {
                preferences = getSharedPreferences("gameData",0);
                editor = preferences.edit();
                String username = preferences.getString("username",null);
                if(username==null) {
                    Intent intent = new Intent(StartAnimationActivity.this, registerActivity.class);
                    startActivity(intent);
                }
                else {
                    Intent intent = new Intent(StartAnimationActivity.this, MainActivity.class);
                    startActivity(intent);
                }
                finish();
            }

            @Override
            public void onAnimationRepeat(Animation animation) {

            }
        });
        am.start();
    }


}
