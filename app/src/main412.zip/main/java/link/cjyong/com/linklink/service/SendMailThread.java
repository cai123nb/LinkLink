package link.cjyong.com.linklink.service;

import android.util.Log;
import android.widget.Toast;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.NoSuchProviderException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import link.cjyong.com.linklink.Activity.registerActivity.registerActivity;

/**
 * Created by cjyong on 2017/4/7.
 */

public class SendMailThread extends Thread {
    public static enum MailType{registerMail,feedbackMail};
    private String recipientAddress;
    private String username;
    private String feedback;
    private String activatedCode;
    private MailType mailType;
    public SendMailThread(String username,String recipientAddress,String activatedCode,MailType mailType){
        this.username=username;
        this.recipientAddress=recipientAddress;
        this.activatedCode=activatedCode;
        this.mailType=mailType;
    }
    public SendMailThread(String username,String feedback,MailType mailType)
    {
        this.username = username;
        this.feedback = feedback;
        this.mailType = mailType;
    }
    public void run(){
        if(mailType==MailType.registerMail) {
            //发送验证码
            Mail m = new Mail("18375637632@163.com", "cai123nb");
            String[] toArr = {recipientAddress};
            m.set_to(toArr);
            m.set_from("18375637632@163.com");
            m.set_subject("LinkLink游戏注册成功");
            m.setBody("恭喜您: " + username + " 注册LinkLink游戏成功,你的激活码是: " + activatedCode + " \n请及时查收");
            try {
                m.send();
            } catch (Exception e) {
                Log.e("MailApp", "Could not send email", e);
            }
            //进行汇总统计
            Mail countM = new Mail("18375637632@163.com", "cai123nb");
            String[] toAddr = {"2686600303@qq.com"};
            countM.set_to(toAddr);
            countM.set_from("18375637632@163.com");
            countM.set_subject("LinkLink游戏用户"+username+"注册成功");
            countM.setBody("LinkLink 有新用户: "+username+"注册成功!");
            try
            {
                countM.send();
            }
            catch (Exception e)
            {
                Log.e("MailApp", "Could not send email", e);
            }
        }
        else if(mailType==MailType.feedbackMail)
        {
            Mail m = new Mail("18375637632@163.com", "cai123nb");
            String[] toAddr = {"2686600303@qq.com"};
            m.set_to(toAddr);
            m.set_from("18375637632@163.com");
            m.set_subject("LinkLink游戏用户"+username+"进行了反馈");
            m.setBody("LinkLink 用户"+username+"反馈内容: "+feedback);
            try
            {
                m.send();
            }
            catch (Exception e)
            {
                Log.e("MailApp", "Could not send email", e);
            }
        }
    }
}
