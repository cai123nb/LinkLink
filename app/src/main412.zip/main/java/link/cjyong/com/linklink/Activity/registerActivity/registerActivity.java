package link.cjyong.com.linklink.Activity.registerActivity;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;
import java.util.Timer;
import java.util.TimerTask;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import link.cjyong.com.linklink.Activity.MainActivity.MainActivity;
import link.cjyong.com.linklink.R;
import link.cjyong.com.linklink.service.Mail;
import link.cjyong.com.linklink.service.SendMailThread;
import link.cjyong.com.linklink.util.HttpUtil;

/**
 * Created by cjyong on 2017/4/8.
 */

public class registerActivity extends Activity
{
    private CheckBox checkBox;
    private EditText etUsername,etEmailAddress,etActivatedCode;
    private Button sendActivated,register;
    private String activatedCode;
    private SharedPreferences preferences;
    private SharedPreferences.Editor editor;
    private Timer timer;
    private int time;
    private Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0x123:
                    sendActivated.setText(" "+time+"秒再次发送");
                    sendActivated.setEnabled(false);
                    time--;
                    if (time < 0) {
                        sendActivated.setText("发送激活码");
                        sendActivated.setEnabled(true);
                        timer.cancel();
                        timer = null;
                        return;
                    }
                    break;
            }
        }
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //设置横屏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.register_main);

        //初始化操作
        init();

    }

    //初始化函数
    private void init()
    {
        //绑定组件
        checkBox = (CheckBox) findViewById(R.id.agree_cb);
        etUsername = (EditText) findViewById(R.id.username);
        etEmailAddress = (EditText) findViewById(R.id.email);
        etActivatedCode = (EditText) findViewById(R.id.activatedCode);
        sendActivated = (Button) findViewById(R.id.Send);
        register = (Button) findViewById(R.id.register);

        //生成激活码
        activatedCode = generateActivatedCode(5);

        //添加监听器
        //发送注册码
        sendActivated.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(goodToSend()) {
                    //发送邮件
                    new SendMailThread(etUsername.getText().toString(),etEmailAddress.getText().toString(),activatedCode, SendMailThread.MailType.registerMail).start();
                    Toast.makeText(registerActivity.this,"发送成功,请及时查收",Toast.LENGTH_LONG).show();
                    //设置20秒CD时间
                    time=20;
                    timer = new Timer();
                    timer.schedule(new TimerTask() {
                        @Override
                        public void run() {
                            handler.sendEmptyMessage(0x123);
                        }
                    }, 0, 1000);
                }
            }
        });

        //进行注册
        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(goodToRegister())
                {
                    register();
                }
            }
        });
    }

    private String generateActivatedCode(int length)
    {
        String base = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        Random random = new Random();
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < length; i++) {
            int number = random.nextInt(base.length());
            sb.append(base.charAt(number));
        }
        return sb.toString();
    }

    private boolean goodToSend()
    {
        if(!checkBox.isChecked())
        {
            //没有点击同意按钮
            Toast.makeText(this,"请点击按钮:我同意以上观点",Toast.LENGTH_SHORT).show();
            return false;
        }
        if(etUsername.getText().toString().equals("")  || etEmailAddress.getText().toString().equals(""))
        {
            //信息没有完全输入
            Toast.makeText(this,"请输入你的用户名和邮箱",Toast.LENGTH_SHORT).show();
            return false;
        }
        //判断是否输入正确的邮箱地址
        String check = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
        Pattern regex = Pattern.compile(check);
        Matcher matcher = regex.matcher(etEmailAddress.getText().toString());
        boolean isMatched = matcher.matches();
        if(!isMatched)
        {
            Toast.makeText(this,"你输入的邮箱有误,请重新输入",Toast.LENGTH_SHORT).show();
            return false;
        }


        //判断网络是否可用
        String html = null;
        // 当前所连接的网络可用
        try {
            html = HttpUtil.sendGetRequest("http://www.bilibili.com", false, null, "utf-8");
            if(html!=null && html.contains("<meta http-equiv="))
            {
                return true;
            }
            else
            {
                Toast.makeText(this,"请确认你的网络已正确连接",Toast.LENGTH_SHORT).show();
                return false;
            }
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
        return false;
    }

    private boolean goodToRegister()
    {
        if(!goodToSend())
        {
            return false;
        }

        if(etActivatedCode.getText().toString().equals(""))
        {
            Toast.makeText(this,"请输入你的激活码",Toast.LENGTH_SHORT).show();
            return false;
        }

        if(!etActivatedCode.getText().toString().equals(activatedCode))
        {
            Toast.makeText(this,"激活码不对应,请再次确认你的邮箱",Toast.LENGTH_SHORT).show();
            return false;
        }

        return true;
    }

    private void register()
    {
        preferences = getSharedPreferences("gameData",0);
        editor = preferences.edit();
        String username = etUsername.getText().toString();
        editor.putString("username",username);
        editor.commit();
        Toast.makeText(this,"恭喜你:"+username+"注册成功",Toast.LENGTH_LONG).show();
        Intent intent = new Intent(this, MainActivity.class);
        startActivity(intent);
        finish();
    }


}
