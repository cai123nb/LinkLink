package link.cjyong.com.linklink.util;

import android.app.Application;

/**
 * Created by cjyong on 2017/3/27.
 */

public class MyApplication extends Application
{
    private static MyApplication instance;

    public static MyApplication getInstance() {
        return instance;
    }

    @Override
    public void onCreate() {
        // TODO Auto-generated method stub
        super.onCreate();
        instance = this;
    }
}
