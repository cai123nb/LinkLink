package link.cjyong.com.linklink.Activity.ThirdHurdleActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

import link.cjyong.com.linklink.Activity.firstHurdleActivity.FirstHurdleActivity;
import link.cjyong.com.linklink.Activity.firstHurdleActivity.GameActivity;
import link.cjyong.com.linklink.R;
import link.cjyong.com.linklink.board.GameService;
import link.cjyong.com.linklink.board.impl.GameServiceImpl;
import link.cjyong.com.linklink.element.GameConf;
import link.cjyong.com.linklink.element.LinkInfo;
import link.cjyong.com.linklink.view.GameView;
import link.cjyong.com.linklink.view.Piece;

/**
 * Created by cjyong on 2017/4/10.
 */

public class GameActivity31 extends Activity {
    private Button pauseBtn,helpBtn,timeBtn,resetBtn,boomBtn;
    private GameView gameView;
    private GameConf config;
    private TextView timeLeft,taskRequirements;
    private GameService gameService;
    private Timer timer = new Timer();
    private int time;
    private Piece selected = null;
    private boolean isPlaying;
    SharedPreferences preferences;
    SharedPreferences.Editor editor;
    // 失败后弹出的对话框
    private AlertDialog.Builder lostDialog;
    // 游戏胜利后的对话框
    private AlertDialog.Builder successDialog;

    private Handler handler = new Handler() {
        public void handleMessage(Message msg) {
            switch (msg.what) {
                case 0x123:
                    timeLeft.setText(""+time);
                    time--;
                    //时间小于0，游戏失败
                    if (time < 0) {
                        stopTimer();
                        isPlaying = false;
                        lostDialog.show();
                        return;
                    }
                    break;
            }
        }
    };

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        //设置横屏
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_LANDSCAPE);
        setContentView(R.layout.game_main);
        init();
        startGame(config.getGameTime());
    }

    private void init()
    {
        //config = new GameConf(8, 9, 2, 10, 60, this);
        config =  getIntent().getParcelableExtra("gameConf");
        gameView = (GameView) findViewById(R.id.gameView);
        timeLeft = (TextView) findViewById(R.id.timeLeft);
        gameService = new GameServiceImpl(this.config);
        pauseBtn = (Button) findViewById(R.id.pauseBtn);
        taskRequirements = (TextView) findViewById(R.id.taskRequirements);
        helpBtn = (Button) findViewById(R.id.helpTool);
        timeBtn = (Button) findViewById(R.id.addTimeTool);
        resetBtn = (Button) findViewById(R.id.resetTool);
        boomBtn = (Button) findViewById(R.id.boomTool);

        //设置任务要求
        taskRequirements.setText(config.getTaskRequirements());

        // 初始化游戏失败的对话框
        lostDialog = createDialog("Lost", "游戏失败！ 重新开始", R.drawable.lost)
                .setPositiveButton("确定", new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int which)
                            {
                                startGame(config.getGameTime());
                            }
                        }
                )
                .setNegativeButton("取消",new DialogInterface.OnClickListener()
                        {
                            public void onClick(DialogInterface dialog, int which)
                            {
                                Intent intent = new Intent(GameActivity31.this, ThirdHurdleActivity.class);
                                startActivity(intent);
                                finish();
                            }
                        }
                );
        // 初始化游戏胜利的对话框
        successDialog = createDialog("Success", "游戏胜利！ 重新开始",
                R.drawable.success).setPositiveButton("再来一盘",
                new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        startGame(config.getGameTime());
                    }
                })
                .setNegativeButton("返回",new DialogInterface.OnClickListener()
                {
                    public void onClick(DialogInterface dialog, int which)
                    {
                        Intent  intent = new Intent(GameActivity31.this,ThirdHurdleActivity.class);
                        startActivity(intent);
                        finish();
                    }
                });


        //绑定监听器
        this.gameView.setOnTouchListener(new View.OnTouchListener() {
                                             public boolean onTouch(View view, MotionEvent e) {
                                                 if (!isPlaying) {
                                                     return false;
                                                 }
                                                 if (e.getAction() == MotionEvent.ACTION_DOWN) {
                                                     gameViewTouchDown(e);
                                                 }
                                                 if (e.getAction() == MotionEvent.ACTION_UP) {
                                                     gameViewTouchUp(e);
                                                 }
                                                 return true;
                                             }
                                         }
        );
        pauseBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //这里应该添加暂停的选项
            }
        });
        //提示卡使用
        helpBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Piece[] tmp1 =  gameService.getUsefulPieces();
                gameView.setSelectedPiece(tmp1[0]);
                gameView.setHelpedPiece(tmp1[1]);
                gameView.postInvalidate();
            }
        });
        //加时卡使用
        timeBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                time+=30;
            }
        });

        //爆炸卡使用
        boomBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameService.clearOneKindPiece();
                time+=5;
                gameView.postInvalidate();
                if (!gameService.hasPieces()) {
                    //游戏胜利
                    success(time);
                    stopTimer();
                    gameView.setLinkInfo(null);
                    isPlaying = false;
                }
                gameView.postInvalidate();
            }
        });

        //重置卡的使用
        resetBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                gameService.resetting();
                gameView.postInvalidate();
            }
        });

        gameView.setGameService(gameService);
    }

    @Override
    protected void onPause() {
        //暂停游戏
        super.onPause();
        stopTimer();

    }

    @Override
    protected  void onResume()
    {
        // 如果处于游戏状态中
        if (isPlaying)
        {
            // 以剩余时间重写开始游戏
            startGame(time);
        }
        super.onResume();
    }


    //游戏区域触碰的处理方法
    private void gameViewTouchDown(MotionEvent event) {
        //获取GameSERVICEImpl中Piece[][]数组
        Piece[][] pieces = gameService.getPieces();
        //获取用户点击的X坐标和Y坐标
        float touchX = event.getX();
        float touchY = event.getY();
        Piece currentPiece = gameService.findPiece(touchX, touchY);
        if (currentPiece == null)
            return;
        this.gameView.setSelectedPiece(currentPiece);
        //第一个被选中
        if (this.selected == null) {
            this.selected = currentPiece;
            this.gameView.postInvalidate();
            return;
        }

        //第二个被选中
        if (this.selected != null) {
            LinkInfo linkInfo = this.gameService.link(this.selected, currentPiece);
            if (linkInfo == null) {
                this.selected = currentPiece;
                this.gameView.postInvalidate();
            } else {
                //连接成功
                handleSuccessLink(linkInfo, this.selected, currentPiece, pieces);
            }
        }
    }

    //触碰游戏区域的处理方法
    private void gameViewTouchUp(MotionEvent event) {
        this.gameView.postInvalidate();
    }

    private void handleSuccessLink(LinkInfo linkInfo, Piece prePiece, Piece currentPiece, Piece[][] pieces) {
        time+=5;
        this.gameView.setLinkInfo(linkInfo);
        this.gameView.setSelectedPiece(null);
        this.gameView.setHelpedPiece(null);
        this.gameView.postInvalidate();
        pieces[prePiece.getIndexX()][prePiece.getIndexY()] = null;
        pieces[currentPiece.getIndexX()][currentPiece.getIndexY()] = null;
        this.selected = null;
        if (!this.gameService.hasPieces()) {
            //游戏胜利
            success(time);
            stopTimer();
            this.gameView.setLinkInfo(null);
            isPlaying = false;
        }
        else {
            if(!this.gameService.haveUsefulLinked()) {
                Toast.makeText(this, "没有可以连接的图标,重置中", Toast.LENGTH_SHORT).show();
                this.gameService.resetting();
            }
            this.gameView.postInvalidate();
        }
    }

    private void stopTimer() {
        this.timer.cancel();
        this.timer = null;
    }

    //开始游戏或者恢复游戏
    private void startGame(int gameTime) {
        //如果之前timer还未取消，取消timer
        if (this.timer != null) {
            stopTimer();
        }
        this.time = gameTime;
        if (time == config.getGameTime()) {
            gameView.startGame();
        }
        isPlaying = true;
        this.timer = new Timer();
        this.timer.schedule(new TimerTask() {
            @Override
            public void run() {
                handler.sendEmptyMessage(0x123);
            }
        }, 0, 1000);
        this.selected = null;
    }




    //成功时调用的方法
    private void success(int leftTime)
    {

        //设置星数
        //这里应该添加计算分数的算法
        int starScore = 1;
        if(leftTime >20)
        {
            starScore = 3;
        }
        else if(leftTime >10)
        {
            starScore = 2;
        }
        //  System.out.println("Time:"+leftTime+" star:"+starScore);
        //获取用户通关数据
        preferences = getSharedPreferences("gameData",0);
        editor = preferences.edit();
        int gold = preferences.getInt("gold",0);
        int diamond = preferences.getInt("diamond",0);

        int currentScore = preferences.getInt(config.getBarrierID(),-1);
        if(starScore>currentScore) {
            editor.putInt(config.getBarrierID(), starScore);
        }
        if(currentScore==0) //第一次玩
        {
            //解锁第二关
            int barrier = Integer.valueOf(config.getBarrierID());
            if (barrier % 10 == 6) {
                barrier = barrier + 10 - 5;
            } else {
                barrier += 1;
            }
            editor.putInt(barrier + "", 0);
        }
        //设置奖励
        //简单奖励系统
        if(starScore<=1)
        {
            gold+=100;
            diamond+=1;
        }
        else if(starScore<=2)
        {
            gold+=200;
            diamond+=2;
        }
        else
        {
            gold+=300;
            diamond+=3;
        }
        editor.putInt("gold",gold);
        editor.putInt("diamond",diamond);
        editor.commit();

        this.successDialog.show();


    }

    // 创建对话框的工具方法
    private AlertDialog.Builder createDialog(String title, String message,
                                             int imageResource)
    {
        return new AlertDialog.Builder(this).setTitle(title)
                .setMessage(message).setIcon(imageResource);
    }
}
